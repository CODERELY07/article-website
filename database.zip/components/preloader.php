<div id="preloader">
    <div class="loader">
    <img src="./assets/logo.png" alt="Sibol logo" class="mx-auto block" width="120">
    <img src="./assets/load.gif" alt="Loading..." class="mx-auto block">
    </div>
</div>